#include "manifest.h"

uint32_t Manifest::Header::disk_size()
{
	return (
		sizeof(magic) + 
		sizeof(version) + 
		sizeof(block_size) +
		sizeof(header_size) + 
		sizeof(reserved) + 
		sizeof(crc32)
	);
}

uint32_t Manifest::Header::compute_crc32()
{
	this->crc32 = ::crc32(0L, Z_NULL, 0);
	crc32_add_pod(this->crc32, this->magic);
	crc32_add_pod(this->crc32, this->version);
	crc32_add_pod(this->crc32, this->block_size);
	crc32_add_pod(this->crc32, this->header_size);
	crc32_add_pod(this->crc32, this->reserved);
}

void Manifest::Header::write(std::ofstream& file)
{
	align_to_block_boundary(file, this->block_size);
	file.write(reinterpret_cast<const char*>(&this->magic), static_cast<std::streamsize>(sizeof(this->magic)));
	file.write(reinterpret_cast<const char*>(&this->version), static_cast<std::streamsize>(sizeof(this->version)));
	file.write(reinterpret_cast<const char*>(&this->block_size), static_cast<std::streamsize>(sizeof(this->block_size)));
	file.write(reinterpret_cast<const char*>(&this->header_size), static_cast<std::streamsize>(sizeof(this->header_size)));
	file.write(reinterpret_cast<const char*>(&this->reserved), static_cast<std::streamsize>(sizeof(this->reserved)));
	file.write(reinterpret_cast<const char*>(&this->crc32), static_cast<std::streamsize>(sizeof(this->crc32)));
}